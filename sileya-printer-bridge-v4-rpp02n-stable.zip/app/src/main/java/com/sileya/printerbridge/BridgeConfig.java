package com.sileya.printerbridge;

public final class BridgeConfig {
    private BridgeConfig() {}

    public static final int PORT = 9200;
    public static final String VERSION = "1.1.0";

    public static final String PREFS = "sileya_bridge";
    public static final String KEY_CASHIER_ADDRESS = "cashier_address";
    public static final String KEY_KITCHEN_ADDRESS = "kitchen_address";

    public static final String ROLE_CASHIER = "cashier";
    public static final String ROLE_KITCHEN = "kitchen";
}
