# RPP02N stability changes

- RPP02N prefers insecure SPP UUID instead of raw RFCOMM channel 1.
- 700 ms connection settle before ESC/POS initialization.
- Flush after each content block with 55 ms pacing.
- 1.6 s tail hold before closing the socket.
- RPP02 cashier behavior remains unchanged.
