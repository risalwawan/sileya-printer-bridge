# Sileya Printer Bridge v1.1.0

Android bridge untuk satu tablet + dua printer Bluetooth Classic / ESC-POS.

## Tujuan

- Printer kasir dan printer dapur sama-sama dipairing ke SATU tablet.
- Tidak ada konsep satu printer default seperti Cleanter.
- Sileya memilih printer berdasarkan `role`, nama Bluetooth, atau MAC address.
- Server lokal berjalan di `http://127.0.0.1:9200`.
- API kompatibel dengan konsep payload Cleanter (`content` blocks) dan juga menerima blok `image` base64 PNG/JPEG.
- Semua job print diserialkan agar printer murah Bluetooth lebih stabil.

## API

- `GET /health`
- `GET /printers`
- `GET /config`
- `POST /config`
- `POST /print`
- `OPTIONS *` untuk CORS / Private Network Access browser.

### Contoh printer kasir

```json
{
  "role": "cashier",
  "paperWidth": 58,
  "reference": "TRX001",
  "cut": false,
  "content": [
    {"type":"text","text":"SILEYA","align":"center","bold":true,"size":"large"},
    {"type":"divider"},
    {"type":"row","left":"TOTAL","right":"Rp 24.000","bold":true},
    {"type":"feed"}
  ]
}
```

### Contoh printer dapur

```json
{
  "role": "kitchen",
  "paperWidth": 58,
  "reference": "MEJA-3",
  "content": [
    {"type":"text","text":"PESANAN DAPUR","align":"center","bold":true,"size":"large"},
    {"type":"row","left":"Cafe Latte","right":"x1"},
    {"type":"feed"}
  ]
}
```

### Cetak PNG dari tampilan struk Sileya

```json
{
  "role":"cashier",
  "paperWidth":58,
  "content":[
    {
      "type":"image",
      "data":"data:image/png;base64,iVBORw0KGgoAAA...",
      "align":"center",
      "dither":false
    }
  ]
}
```

## Build

Project dibuat untuk Android Studio / Android SDK 35, Java 17.

1. Install Android Studio.
2. File -> Open -> pilih folder `SileyaPrinterBridge`.
3. Tunggu Gradle sync.
4. Build -> Build APK(s).
5. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Environment ChatGPT yang membuat source ini tidak memiliki Android SDK, sehingga ZIP ini berisi project source yang siap dibuild, bukan APK prebuilt.

## Instalasi di tablet

1. Pair kedua printer dari Android Settings terlebih dahulu, mis. `RPP02` dan `RPP02N`.
2. Install APK.
3. Buka Sileya Printer Bridge.
4. Izinkan Nearby devices / Bluetooth dan notifikasi bila diminta.
5. Pilih printer kasir dan printer dapur dari dua dropdown.
6. Tekan `Simpan Mapping`.
7. Tekan `Mulai Bridge`.
8. Tekan `Tes Printer Kasir` lalu `Tes Printer Dapur`.
9. Dari Chrome tablet buka `http://127.0.0.1:9200/health` untuk cek bridge.

Setelah dua tombol tes berhasil, baru ubah Sileya dari port Cleanter `9100` ke bridge `9200`.

## v1.1 RPP compatibility
This build prefers RFCOMM channel 1 for RPP02/RPP02N/EPPOS-class printers, cancels Bluetooth discovery before connect, uses CRLF line endings, and keeps the socket open briefly after flush. This addresses printers that report a successful Bluetooth write but do not physically feed paper.
