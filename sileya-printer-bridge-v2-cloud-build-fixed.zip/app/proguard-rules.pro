# Sileya Printer Bridge - no shrinking rules required for v1.
