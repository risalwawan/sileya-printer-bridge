package com.sileya.printerbridge;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public final class BridgeServer {
    private static final int MAX_BODY = 12 * 1024 * 1024;

    private final Context context;
    private final int port;
    private final ExecutorService clientPool = Executors.newCachedThreadPool();
    private final ExecutorService printQueue = Executors.newSingleThreadExecutor();

    private volatile boolean running;
    private ServerSocket serverSocket;
    private Thread acceptThread;

    public BridgeServer(Context context, int port) {
        this.context = context.getApplicationContext();
        this.port = port;
    }

    public synchronized void start() {
        if (running) return;
        running = true;
        acceptThread = new Thread(this::acceptLoop, "Sileya-Bridge-Accept");
        acceptThread.start();
    }

    public synchronized void stop() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {}
        clientPool.shutdownNow();
        printQueue.shutdownNow();
    }

    private void acceptLoop() {
        try {
            serverSocket = new ServerSocket(port, 20, InetAddress.getByName("127.0.0.1"));
            while (running) {
                Socket socket = serverSocket.accept();
                clientPool.execute(() -> handleClient(socket));
            }
        } catch (IOException e) {
            if (running) running = false;
        }
    }

    private void handleClient(Socket socket) {
        try (Socket client = socket;
             InputStream rawIn = new BufferedInputStream(client.getInputStream());
             OutputStream rawOut = new BufferedOutputStream(client.getOutputStream())) {

            client.setSoTimeout(15000);
            String requestLine = readLine(rawIn);
            if (requestLine == null || requestLine.trim().isEmpty()) {
                return;
            }

            String[] requestParts = requestLine.split(" ");
            if (requestParts.length < 2) {
                sendJson(rawOut, 400, error("bad_request", "Request line tidak valid."));
                return;
            }

            String method = requestParts[0].toUpperCase(Locale.US);
            String rawPath = requestParts[1];
            String path = rawPath.contains("?") ? rawPath.substring(0, rawPath.indexOf('?')) : rawPath;

            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = readLine(rawIn)) != null && !line.isEmpty()) {
                int colon = line.indexOf(':');
                if (colon > 0) {
                    headers.put(
                            line.substring(0, colon).trim().toLowerCase(Locale.US),
                            line.substring(colon + 1).trim()
                    );
                }
            }

            if ("OPTIONS".equals(method)) {
                sendNoContent(rawOut);
                return;
            }

            byte[] body = new byte[0];
            int contentLength = parseInt(headers.get("content-length"), 0);
            if (contentLength < 0 || contentLength > MAX_BODY) {
                sendJson(rawOut, 413, error("payload_too_large", "Payload terlalu besar."));
                return;
            }
            if (contentLength > 0) {
                body = readExactly(rawIn, contentLength);
            }

            route(rawOut, method, path, body);
        } catch (Exception ignored) {
            // Client may close the browser request. Keep the bridge alive for the next request.
        }
    }

    private void route(OutputStream out, String method, String path, byte[] body) throws Exception {
        if ("GET".equals(method) && ("/".equals(path) || "/health".equals(path))) {
            sendJson(out, 200, health());
            return;
        }

        if ("GET".equals(method) && "/printers".equals(path)) {
            JSONObject json = new JSONObject();
            json.put("status", "ok");
            json.put("printers", PrinterManager.listPaired(context));
            sendJson(out, 200, json);
            return;
        }

        if ("GET".equals(method) && "/config".equals(path)) {
            sendJson(out, 200, configJson());
            return;
        }

        if ("POST".equals(method) && "/config".equals(path)) {
            JSONObject payload = parseJson(body);
            SharedPreferences prefs = context.getSharedPreferences(BridgeConfig.PREFS, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            if (payload.has("cashierAddress")) {
                editor.putString(BridgeConfig.KEY_CASHIER_ADDRESS, payload.optString("cashierAddress", "").trim());
            }
            if (payload.has("kitchenAddress")) {
                editor.putString(BridgeConfig.KEY_KITCHEN_ADDRESS, payload.optString("kitchenAddress", "").trim());
            }
            editor.apply();
            sendJson(out, 200, configJson());
            return;
        }

        if ("POST".equals(method) && "/print".equals(path)) {
            JSONObject payload = parseJson(body);
            Future<JSONObject> future = printQueue.submit(() -> PrinterManager.printJob(context, payload));
            try {
                JSONObject result = future.get(60, TimeUnit.SECONDS);
                sendJson(out, 200, result);
            } catch (Exception e) {
                future.cancel(true);
                String detail = rootMessage(e);
                sendJson(out, 503, error("printer_unreachable", detail));
            }
            return;
        }

        sendJson(out, 404, error("not_found", "Endpoint tidak ditemukan: " + path));
    }

    private JSONObject health() throws Exception {
        JSONObject json = new JSONObject();
        json.put("status", "ok");
        json.put("bridge", "Sileya Printer Bridge");
        json.put("version", BridgeConfig.VERSION);
        json.put("port", port);

        BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        json.put("bluetoothEnabled", adapter != null && adapter.isEnabled());
        json.put("printers", PrinterManager.listPaired(context));
        json.put("roles", roleJson());

        // Compatibility field for pages that only check health.printer.connected.
        JSONObject compatPrinter = new JSONObject();
        compatPrinter.put("connected", true);
        compatPrinter.put("name", "Sileya multi-printer bridge");
        json.put("printer", compatPrinter);
        return json;
    }

    private JSONObject configJson() throws Exception {
        JSONObject json = new JSONObject();
        json.put("status", "ok");
        json.put("roles", roleJson());
        return json;
    }

    private JSONObject roleJson() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(BridgeConfig.PREFS, Context.MODE_PRIVATE);
        JSONObject roles = new JSONObject();
        roles.put(BridgeConfig.ROLE_CASHIER,
                PrinterManager.describeAddress(context, prefs.getString(BridgeConfig.KEY_CASHIER_ADDRESS, "")));
        roles.put(BridgeConfig.ROLE_KITCHEN,
                PrinterManager.describeAddress(context, prefs.getString(BridgeConfig.KEY_KITCHEN_ADDRESS, "")));
        return roles;
    }

    private JSONObject parseJson(byte[] body) throws Exception {
        if (body == null || body.length == 0) return new JSONObject();
        return new JSONObject(new String(body, StandardCharsets.UTF_8));
    }

    private JSONObject error(String code, String detail) throws Exception {
        JSONObject json = new JSONObject();
        json.put("status", "error");
        json.put("error", code);
        json.put("detail", detail == null || detail.isEmpty() ? code : detail);
        return json;
    }

    private void sendJson(OutputStream out, int status, JSONObject json) throws IOException {
        byte[] bytes = json.toString().getBytes(StandardCharsets.UTF_8);
        String headers = "HTTP/1.1 " + status + " " + statusText(status) + "\r\n" +
                "Content-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: " + bytes.length + "\r\n" +
                corsHeaders() +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n";
        out.write(headers.getBytes(StandardCharsets.US_ASCII));
        out.write(bytes);
        out.flush();
    }

    private void sendNoContent(OutputStream out) throws IOException {
        String headers = "HTTP/1.1 204 No Content\r\n" +
                "Content-Length: 0\r\n" +
                corsHeaders() +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n";
        out.write(headers.getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    private String corsHeaders() {
        return "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Accept\r\n" +
                "Access-Control-Allow-Private-Network: true\r\n";
    }

    private String statusText(int status) {
        switch (status) {
            case 200: return "OK";
            case 204: return "No Content";
            case 400: return "Bad Request";
            case 404: return "Not Found";
            case 409: return "Conflict";
            case 413: return "Payload Too Large";
            case 503: return "Service Unavailable";
            default: return "Response";
        }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') break;
            if (b != '\r') buffer.write(b);
            if (buffer.size() > 16384) throw new IOException("Header terlalu panjang");
        }
        if (b == -1 && buffer.size() == 0) return null;
        return buffer.toString(StandardCharsets.ISO_8859_1.name());
    }

    private static byte[] readExactly(InputStream in, int count) throws IOException {
        byte[] data = new byte[count];
        int offset = 0;
        while (offset < count) {
            int read = in.read(data, offset, count - offset);
            if (read < 0) throw new IOException("Request body terputus");
            offset += read;
        }
        return data;
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value == null ? "" : value.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static String rootMessage(Throwable throwable) {
        Throwable current = throwable;
        while (current.getCause() != null) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.trim().isEmpty()
                ? current.getClass().getSimpleName()
                : message;
    }
}
