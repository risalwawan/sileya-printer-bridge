package com.sileya.printerbridge;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class PrinterManager {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final Charset TEXT_CHARSET = Charset.forName("CP437");

    private PrinterManager() {}

    public static JSONArray listPaired(Context context) throws Exception {
        ensurePermission(context);
        JSONArray array = new JSONArray();
        BluetoothAdapter adapter = adapter(context);
        if (adapter == null) return array;
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        List<BluetoothDevice> devices = new ArrayList<>(bonded);
        devices.sort((a, b) -> safeName(a).compareToIgnoreCase(safeName(b)));
        for (BluetoothDevice device : devices) {
            JSONObject row = new JSONObject();
            row.put("name", safeName(device));
            row.put("address", safeAddress(device));
            row.put("bonded", device.getBondState() == BluetoothDevice.BOND_BONDED);
            array.put(row);
        }
        return array;
    }

    public static JSONObject describeAddress(Context context, String address) throws Exception {
        JSONObject row = new JSONObject();
        row.put("address", address == null ? "" : address);
        row.put("configured", address != null && !address.trim().isEmpty());
        row.put("paired", false);
        row.put("name", "");

        if (address == null || address.trim().isEmpty()) return row;
        try {
            BluetoothDevice device = findByAddress(context, address.trim());
            if (device != null) {
                row.put("paired", true);
                row.put("name", safeName(device));
                row.put("address", safeAddress(device));
            }
        } catch (Exception ignored) {}
        return row;
    }

    public static JSONObject printJob(Context context, JSONObject payload) throws Exception {
        ensurePermission(context);
        BluetoothAdapter adapter = adapter(context);
        if (adapter == null) throw new IOException("Bluetooth tidak tersedia di tablet.");
        if (!adapter.isEnabled()) throw new IOException("Bluetooth sedang mati.");

        BluetoothDevice device = resolveDevice(context, payload);
        if (device == null) {
            throw new IOException("Printer target tidak ditemukan atau belum paired.");
        }

        int paperWidth = payload.optInt("paperWidth", 58) == 80 ? 80 : 58;
        boolean cut = payload.optBoolean("cut", false);
        String reference = payload.optString("reference", "");
        JSONArray content = payload.optJSONArray("content");
        if (content == null) content = new JSONArray();

        BluetoothSocket socket = connect(device);
        try {
            OutputStream out = socket.getOutputStream();
            write(out, 0x1B, 0x40); // ESC @ initialize
            write(out, 0x1B, 0x74, 0x00); // CP437/default page

            for (int i = 0; i < content.length(); i++) {
                JSONObject block = content.optJSONObject(i);
                if (block == null) continue;
                printBlock(out, block, paperWidth);
            }

            if (cut) {
                // Portable 58mm printers often ignore this safely if no cutter exists.
                write(out, 0x1D, 0x56, 0x00);
            }
            out.flush();
        } finally {
            try { socket.close(); } catch (Exception ignored) {}
        }

        JSONObject result = new JSONObject();
        result.put("status", "printed");
        result.put("jobId", UUID.randomUUID().toString());
        result.put("reference", reference);
        JSONObject printer = new JSONObject();
        printer.put("name", safeName(device));
        printer.put("address", safeAddress(device));
        result.put("printer", printer);
        return result;
    }

    public static void printTest(Context context, String address, String role) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("printerAddress", address);
        payload.put("paperWidth", 58);
        payload.put("cut", false);
        payload.put("reference", "TEST-" + role.toUpperCase(Locale.US));

        JSONArray content = new JSONArray();
        content.put(new JSONObject()
                .put("type", "text")
                .put("text", "SILEYA PRINTER BRIDGE")
                .put("align", "center")
                .put("bold", true)
                .put("size", "large"));
        content.put(new JSONObject().put("type", "divider"));
        content.put(new JSONObject()
                .put("type", "text")
                .put("text", "TEST PRINTER " + role.toUpperCase(Locale.US))
                .put("align", "center")
                .put("bold", true));
        content.put(new JSONObject()
                .put("type", "text")
                .put("text", "Address: " + address)
                .put("align", "center"));
        content.put(new JSONObject().put("type", "divider"));
        content.put(new JSONObject()
                .put("type", "text")
                .put("text", "Jika kertas ini keluar dari printer yang benar, mapping berhasil.")
                .put("align", "center"));
        content.put(new JSONObject().put("type", "feed").put("lines", 3));
        payload.put("content", content);
        printJob(context, payload);
    }

    private static void printBlock(OutputStream out, JSONObject block, int paperWidth) throws Exception {
        String type = block.optString("type", "text").toLowerCase(Locale.US);
        switch (type) {
            case "text":
                printText(out, block);
                break;
            case "row":
                printRow(out, block, paperWidth);
                break;
            case "divider":
                printDivider(out, block, paperWidth);
                break;
            case "feed":
                int lines = Math.max(1, Math.min(12, block.optInt("lines", 1)));
                for (int i = 0; i < lines; i++) out.write('\n');
                break;
            case "image":
                printImage(out, block, paperWidth);
                break;
            default:
                throw new IOException("Content type belum didukung: " + type);
        }
    }

    private static void printText(OutputStream out, JSONObject block) throws Exception {
        String text = block.optString("text", "");
        String align = block.optString("align", "left");
        boolean bold = block.optBoolean("bold", false);
        boolean underline = block.optBoolean("underline", false);
        String size = block.optString("size", "normal");

        setAlign(out, align);
        write(out, 0x1B, 0x45, bold ? 1 : 0);
        write(out, 0x1B, 0x2D, underline ? 1 : 0);

        if ("large".equalsIgnoreCase(size)) {
            write(out, 0x1D, 0x21, 0x11); // double width + double height
            write(out, 0x1B, 0x4D, 0x00);
        } else if ("small".equalsIgnoreCase(size)) {
            write(out, 0x1D, 0x21, 0x00);
            write(out, 0x1B, 0x4D, 0x01); // Font B when supported
        } else {
            write(out, 0x1D, 0x21, 0x00);
            write(out, 0x1B, 0x4D, 0x00);
        }

        out.write(text.getBytes(TEXT_CHARSET));
        out.write('\n');

        // Reset block styles.
        write(out, 0x1D, 0x21, 0x00);
        write(out, 0x1B, 0x4D, 0x00);
        write(out, 0x1B, 0x45, 0x00);
        write(out, 0x1B, 0x2D, 0x00);
        setAlign(out, "left");
    }

    private static void printRow(OutputStream out, JSONObject block, int paperWidth) throws Exception {
        int chars = paperWidth == 80 ? 48 : 32;
        String left = oneLine(block.optString("left", ""));
        String right = oneLine(block.optString("right", ""));
        boolean bold = block.optBoolean("bold", false);

        if (right.length() >= chars) right = right.substring(0, chars - 1);
        int maxLeft = Math.max(1, chars - right.length() - 1);
        if (left.length() > maxLeft) left = left.substring(0, maxLeft);
        int spaces = Math.max(1, chars - left.length() - right.length());
        StringBuilder line = new StringBuilder(left);
        for (int i = 0; i < spaces; i++) line.append(' ');
        line.append(right);

        setAlign(out, "left");
        write(out, 0x1B, 0x45, bold ? 1 : 0);
        out.write(line.toString().getBytes(TEXT_CHARSET));
        out.write('\n');
        write(out, 0x1B, 0x45, 0x00);
    }

    private static void printDivider(OutputStream out, JSONObject block, int paperWidth) throws Exception {
        int chars = paperWidth == 80 ? 48 : 32;
        String charValue = block.optString("char", "-");
        char c = charValue.isEmpty() ? '-' : charValue.charAt(0);
        StringBuilder line = new StringBuilder(chars);
        for (int i = 0; i < chars; i++) line.append(c);
        out.write(line.toString().getBytes(StandardCharsets.US_ASCII));
        out.write('\n');
    }

    private static void printImage(OutputStream out, JSONObject block, int paperWidth) throws Exception {
        String base64 = block.optString("base64", "");
        if (base64.isEmpty()) base64 = block.optString("data", "");
        if (base64.isEmpty()) base64 = block.optString("src", "");
        if (base64.contains(",")) base64 = base64.substring(base64.indexOf(',') + 1);
        if (base64.trim().isEmpty()) throw new IOException("Image base64 kosong.");

        byte[] bytes;
        try {
            bytes = Base64.decode(base64, Base64.DEFAULT);
        } catch (Exception e) {
            throw new IOException("Image base64 tidak valid.");
        }
        Bitmap source = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        if (source == null) throw new IOException("PNG/JPEG tidak dapat dibaca.");

        int maxDots = paperWidth == 80 ? 576 : 384;
        Bitmap bitmap = source;
        if (source.getWidth() > maxDots) {
            int targetH = Math.max(1, Math.round(source.getHeight() * (maxDots / (float) source.getWidth())));
            bitmap = Bitmap.createScaledBitmap(source, maxDots, targetH, true);
        }

        setAlign(out, block.optString("align", "center"));
        boolean dither = block.optBoolean("dither", false);
        writeRaster(out, bitmap, dither);
        out.write('\n');
        setAlign(out, "left");

        if (bitmap != source) bitmap.recycle();
        source.recycle();
    }

    private static void writeRaster(OutputStream out, Bitmap bitmap, boolean dither) throws IOException {
        final int bandHeight = 192;
        int width = bitmap.getWidth();
        int widthBytes = (width + 7) / 8;
        int[] pixels = new int[width * Math.min(bandHeight, bitmap.getHeight())];

        for (int y0 = 0; y0 < bitmap.getHeight(); y0 += bandHeight) {
            int h = Math.min(bandHeight, bitmap.getHeight() - y0);
            if (pixels.length < width * h) pixels = new int[width * h];
            bitmap.getPixels(pixels, 0, width, 0, y0, width, h);

            byte[] raster = new byte[widthBytes * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < width; x++) {
                    int color = pixels[y * width + x];
                    int alpha = Color.alpha(color);
                    int r = Color.red(color);
                    int g = Color.green(color);
                    int b = Color.blue(color);
                    int luminance = (r * 299 + g * 587 + b * 114) / 1000;
                    if (alpha < 96) luminance = 255;

                    int threshold = 180;
                    if (dither) {
                        int[][] bayer = {
                                {15, 135, 45, 165},
                                {195, 75, 225, 105},
                                {60, 180, 30, 150},
                                {240, 120, 210, 90}
                        };
                        threshold = bayer[y & 3][x & 3];
                    }

                    if (luminance < threshold) {
                        int index = y * widthBytes + (x / 8);
                        raster[index] |= (byte) (0x80 >> (x & 7));
                    }
                }
            }

            // GS v 0 m xL xH yL yH d1...dk
            out.write(0x1D);
            out.write(0x76);
            out.write(0x30);
            out.write(0x00);
            out.write(widthBytes & 0xFF);
            out.write((widthBytes >> 8) & 0xFF);
            out.write(h & 0xFF);
            out.write((h >> 8) & 0xFF);
            out.write(raster);
            out.flush();
        }
    }

    private static BluetoothDevice resolveDevice(Context context, JSONObject payload) throws Exception {
        String role = payload.optString("role", "").trim().toLowerCase(Locale.US);
        String address = payload.optString("printerAddress", "").trim();
        String printer = payload.optString("printer", "").trim();

        if (!role.isEmpty()) {
            SharedPreferences prefs = context.getSharedPreferences(BridgeConfig.PREFS, Context.MODE_PRIVATE);
            if (BridgeConfig.ROLE_CASHIER.equals(role)) {
                address = prefs.getString(BridgeConfig.KEY_CASHIER_ADDRESS, "");
            } else if (BridgeConfig.ROLE_KITCHEN.equals(role)) {
                address = prefs.getString(BridgeConfig.KEY_KITCHEN_ADDRESS, "");
            } else {
                throw new IOException("Role printer tidak dikenal: " + role);
            }
        }

        if (address != null && !address.trim().isEmpty()) {
            BluetoothDevice byAddress = findByAddress(context, address.trim());
            if (byAddress != null) return byAddress;
            throw new IOException("Printer address " + address + " belum paired.");
        }

        if (!printer.isEmpty()) {
            if (printer.matches("(?i)^([0-9A-F]{2}:){5}[0-9A-F]{2}$")) {
                BluetoothDevice byAddress = findByAddress(context, printer);
                if (byAddress != null) return byAddress;
            }
            return findByName(context, printer);
        }

        // Backward-compatible default: if Sileya sends the old Cleanter-like payload
        // without a printer target, use the saved cashier printer.
        SharedPreferences prefs = context.getSharedPreferences(BridgeConfig.PREFS, Context.MODE_PRIVATE);
        String cashierAddress = prefs.getString(BridgeConfig.KEY_CASHIER_ADDRESS, "");
        if (cashierAddress != null && !cashierAddress.trim().isEmpty()) {
            BluetoothDevice cashier = findByAddress(context, cashierAddress.trim());
            if (cashier != null) return cashier;
        }

        throw new IOException("Printer target belum ditentukan. Simpan mapping printer kasir/dapur di aplikasi bridge.");
    }

    private static BluetoothDevice findByAddress(Context context, String address) throws Exception {
        ensurePermission(context);
        BluetoothAdapter adapter = adapter(context);
        if (adapter == null) return null;
        for (BluetoothDevice device : adapter.getBondedDevices()) {
            if (address.equalsIgnoreCase(safeAddress(device))) return device;
        }
        return null;
    }

    private static BluetoothDevice findByName(Context context, String name) throws Exception {
        ensurePermission(context);
        BluetoothAdapter adapter = adapter(context);
        if (adapter == null) return null;
        BluetoothDevice found = null;
        for (BluetoothDevice device : adapter.getBondedDevices()) {
            if (name.equalsIgnoreCase(safeName(device))) {
                if (found != null) {
                    throw new IOException("Ada lebih dari satu perangkat bernama " + name + ". Gunakan role atau printerAddress.");
                }
                found = device;
            }
        }
        if (found == null) throw new IOException("Printer " + name + " belum paired.");
        return found;
    }

    private static BluetoothSocket connect(BluetoothDevice device) throws Exception {
        Exception first = null;

        try {
            BluetoothSocket secure = device.createRfcommSocketToServiceRecord(SPP_UUID);
            secure.connect();
            return secure;
        } catch (Exception e) {
            first = e;
        }

        try {
            BluetoothSocket insecure = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
            insecure.connect();
            return insecure;
        } catch (Exception ignored) {}

        // Fallback used by many low-cost SPP thermal printers that expose RFCOMM channel 1.
        try {
            Method method = device.getClass().getMethod("createRfcommSocket", int.class);
            BluetoothSocket channelOne = (BluetoothSocket) method.invoke(device, 1);
            channelOne.connect();
            return channelOne;
        } catch (Exception fallback) {
            String message = fallback.getMessage();
            if (message == null || message.trim().isEmpty()) {
                message = first == null ? "Koneksi Bluetooth gagal." : first.getMessage();
            }
            throw new IOException("Tidak dapat terhubung ke " + safeName(device) + ": " + message, fallback);
        }
    }

    private static BluetoothAdapter adapter(Context context) {
        BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        return manager == null ? null : manager.getAdapter();
    }

    private static void ensurePermission(Context context) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            throw new IOException("Izin Nearby devices / Bluetooth belum diberikan ke Sileya Printer Bridge.");
        }
    }

    private static String safeName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return name == null || name.trim().isEmpty() ? "Bluetooth Printer" : name.trim();
        } catch (Exception e) {
            return "Bluetooth Printer";
        }
    }

    private static String safeAddress(BluetoothDevice device) {
        try {
            String address = device.getAddress();
            return address == null ? "" : address.trim();
        } catch (Exception e) {
            return "";
        }
    }

    private static String oneLine(String value) {
        return value == null ? "" : value.replace('\r', ' ').replace('\n', ' ').trim();
    }

    private static void setAlign(OutputStream out, String align) throws IOException {
        int n = "center".equalsIgnoreCase(align) ? 1 : ("right".equalsIgnoreCase(align) ? 2 : 0);
        write(out, 0x1B, 0x61, n);
    }

    private static void write(OutputStream out, int... bytes) throws IOException {
        for (int value : bytes) out.write(value & 0xFF);
    }
}
