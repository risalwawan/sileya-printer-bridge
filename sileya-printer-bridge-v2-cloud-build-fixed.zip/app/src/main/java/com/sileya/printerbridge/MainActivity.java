package com.sileya.printerbridge;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSIONS = 1201;

    private TextView statusText;
    private TextView pairedInfo;
    private Spinner cashierSpinner;
    private Spinner kitchenSpinner;
    private final List<PrinterChoice> choices = new ArrayList<>();

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(BridgeConfig.PREFS, MODE_PRIVATE);
        setContentView(buildUi());
        requestPermissionsIfNeeded();
        refreshPrinters();
        refreshServiceStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPrinters();
        refreshServiceStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(root);

        TextView title = text("Sileya Printer Bridge", 26, true);
        root.addView(title);

        TextView subtitle = text(
                "1 tablet -> 2 printer Bluetooth ESC/POS. Bridge lokal: http://127.0.0.1:9200",
                14, false
        );
        subtitle.setTextColor(Color.DKGRAY);
        root.addView(subtitle, marginTop(6));

        statusText = text("Status bridge: memeriksa...", 15, true);
        root.addView(statusText, marginTop(16));

        Button bluetoothSettings = button("Buka Pengaturan Bluetooth");
        bluetoothSettings.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        root.addView(bluetoothSettings, marginTop(14));

        pairedInfo = text("Printer paired: -", 13, false);
        pairedInfo.setTextColor(Color.DKGRAY);
        root.addView(pairedInfo, marginTop(14));

        root.addView(section("Printer Kasir"), marginTop(20));
        cashierSpinner = new Spinner(this);
        root.addView(cashierSpinner, fullWidth());

        root.addView(section("Printer Dapur"), marginTop(18));
        kitchenSpinner = new Spinner(this);
        root.addView(kitchenSpinner, fullWidth());

        Button refresh = button("Muat Ulang Printer Paired");
        refresh.setOnClickListener(v -> refreshPrinters());
        root.addView(refresh, marginTop(14));

        Button save = button("Simpan Mapping");
        save.setOnClickListener(v -> saveMapping());
        root.addView(save, marginTop(10));

        LinearLayout serviceRow = new LinearLayout(this);
        serviceRow.setOrientation(LinearLayout.HORIZONTAL);
        serviceRow.setGravity(Gravity.CENTER_VERTICAL);
        Button start = button("Mulai Bridge");
        Button stop = button("Stop Bridge");
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half.setMargins(0, dp(12), dp(6), 0);
        serviceRow.addView(start, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half2.setMargins(dp(6), dp(12), 0, 0);
        serviceRow.addView(stop, half2);
        root.addView(serviceRow);

        start.setOnClickListener(v -> startBridge());
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, BridgeService.class));
            statusText.postDelayed(this::refreshServiceStatus, 300);
        });

        Button testCashier = button("Tes Printer Kasir");
        testCashier.setOnClickListener(v -> testRole(BridgeConfig.ROLE_CASHIER));
        root.addView(testCashier, marginTop(20));

        Button testKitchen = button("Tes Printer Dapur");
        testKitchen.setOnClickListener(v -> testRole(BridgeConfig.ROLE_KITCHEN));
        root.addView(testKitchen, marginTop(10));

        TextView help = text(
                "Sesudah dua tombol tes berhasil, Sileya dapat mengirim job dengan role 'cashier' atau 'kitchen'. " +
                        "Bridge akan membuka koneksi ke printer yang dipilih, mencetak, lalu menutup koneksi sebelum job berikutnya.",
                13, false
        );
        help.setTextColor(Color.DKGRAY);
        root.addView(help, marginTop(18));

        return scroll;
    }

    private TextView section(String value) {
        TextView v = text(value, 16, true);
        v.setPadding(0, dp(4), 0, dp(6));
        return v;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(25, 25, 25));
        if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams marginTop(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.topMargin = dp(topDp);
        return p;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void requestPermissionsIfNeeded() {
        List<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            refreshPrinters();
        }
    }

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        return manager == null ? null : manager.getAdapter();
    }

    private void refreshPrinters() {
        if (cashierSpinner == null || kitchenSpinner == null) return;

        String cashierSaved = prefs.getString(BridgeConfig.KEY_CASHIER_ADDRESS, "");
        String kitchenSaved = prefs.getString(BridgeConfig.KEY_KITCHEN_ADDRESS, "");

        choices.clear();
        choices.add(new PrinterChoice("Pilih printer...", ""));

        if (!hasBluetoothPermission()) {
            pairedInfo.setText("Izin Bluetooth/Nearby devices belum diberikan.");
            applySpinnerAdapters(cashierSaved, kitchenSaved);
            return;
        }

        BluetoothAdapter adapter = adapter();
        if (adapter == null) {
            pairedInfo.setText("Bluetooth tidak tersedia pada perangkat ini.");
            applySpinnerAdapters(cashierSaved, kitchenSaved);
            return;
        }

        if (!adapter.isEnabled()) {
            pairedInfo.setText("Bluetooth sedang mati. Nyalakan Bluetooth lalu muat ulang.");
            applySpinnerAdapters(cashierSaved, kitchenSaved);
            return;
        }

        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            List<PrinterChoice> found = new ArrayList<>();
            for (BluetoothDevice device : bonded) {
                String name = safeName(device);
                String address = safeAddress(device);
                if (address.isEmpty()) continue;
                found.add(new PrinterChoice(name.isEmpty() ? "Bluetooth device" : name, address));
            }
            found.sort(Comparator.comparing(a -> a.name.toLowerCase()));
            choices.addAll(found);
            pairedInfo.setText("Perangkat paired ditemukan: " + found.size() +
                    ". Pilih RPP02/RPP02N sesuai printer fisik Anda.");
        } catch (SecurityException e) {
            pairedInfo.setText("Akses perangkat Bluetooth ditolak. Berikan izin Nearby devices.");
        }

        applySpinnerAdapters(cashierSaved, kitchenSaved);
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? "" : n.trim();
        } catch (SecurityException e) {
            return "";
        }
    }

    private String safeAddress(BluetoothDevice d) {
        try {
            String a = d.getAddress();
            return a == null ? "" : a.trim();
        } catch (SecurityException e) {
            return "";
        }
    }

    private void applySpinnerAdapters(String cashierSaved, String kitchenSaved) {
        ArrayAdapter<PrinterChoice> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                new ArrayList<>(choices)
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cashierSpinner.setAdapter(adapter);
        kitchenSpinner.setAdapter(adapter);
        selectAddress(cashierSpinner, cashierSaved);
        selectAddress(kitchenSpinner, kitchenSaved);
    }

    private void selectAddress(Spinner spinner, String address) {
        if (address == null || address.isEmpty()) return;
        for (int i = 0; i < choices.size(); i++) {
            if (address.equalsIgnoreCase(choices.get(i).address)) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private void saveMapping() {
        PrinterChoice cashier = (PrinterChoice) cashierSpinner.getSelectedItem();
        PrinterChoice kitchen = (PrinterChoice) kitchenSpinner.getSelectedItem();
        if (cashier == null || cashier.address.isEmpty()) {
            toast("Pilih printer kasir.");
            return;
        }
        if (kitchen == null || kitchen.address.isEmpty()) {
            toast("Pilih printer dapur.");
            return;
        }
        if (cashier.address.equalsIgnoreCase(kitchen.address)) {
            toast("Printer kasir dan dapur harus berbeda.");
            return;
        }

        prefs.edit()
                .putString(BridgeConfig.KEY_CASHIER_ADDRESS, cashier.address)
                .putString(BridgeConfig.KEY_KITCHEN_ADDRESS, kitchen.address)
                .apply();
        toast("Mapping tersimpan: kasir=" + cashier.name + ", dapur=" + kitchen.name);
    }

    private void startBridge() {
        if (!hasBluetoothPermission()) {
            requestPermissionsIfNeeded();
            toast("Berikan izin Bluetooth terlebih dahulu.");
            return;
        }
        Intent intent = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        statusText.postDelayed(this::refreshServiceStatus, 500);
    }

    private void refreshServiceStatus() {
        if (statusText == null) return;
        if (BridgeService.isRunning()) {
            statusText.setText("Status bridge: AKTIF - http://127.0.0.1:" + BridgeConfig.PORT);
            statusText.setTextColor(Color.rgb(0, 110, 55));
        } else {
            statusText.setText("Status bridge: STOP");
            statusText.setTextColor(Color.rgb(175, 45, 45));
        }
    }

    private void testRole(String role) {
        if (!hasBluetoothPermission()) {
            requestPermissionsIfNeeded();
            toast("Berikan izin Bluetooth terlebih dahulu.");
            return;
        }
        String key = BridgeConfig.ROLE_CASHIER.equals(role)
                ? BridgeConfig.KEY_CASHIER_ADDRESS
                : BridgeConfig.KEY_KITCHEN_ADDRESS;
        String address = prefs.getString(key, "");
        if (address == null || address.isEmpty()) {
            toast("Simpan mapping printer terlebih dahulu.");
            return;
        }

        toast("Mengirim tes ke printer " + (BridgeConfig.ROLE_CASHIER.equals(role) ? "kasir" : "dapur") + "...");
        new Thread(() -> {
            try {
                PrinterManager.printTest(this, address, role);
                runOnUiThread(() -> toast("Tes berhasil dicetak ke " + role + "."));
            } catch (Exception e) {
                runOnUiThread(() -> toast("Tes gagal: " + e.getMessage()));
            }
        }, "Sileya-Test-Printer").start();
    }

    private void toast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_LONG).show();
    }

    static final class PrinterChoice {
        final String name;
        final String address;

        PrinterChoice(String name, String address) {
            this.name = name;
            this.address = address;
        }

        @Override
        public String toString() {
            if (address == null || address.isEmpty()) return name;
            return name + "  (" + address + ")";
        }
    }
}
