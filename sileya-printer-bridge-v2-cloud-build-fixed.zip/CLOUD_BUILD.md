# Build APK tanpa Android Studio

Project ini sudah dilengkapi GitHub Actions. Build APK dilakukan di server GitHub, jadi laptop tidak perlu Android Studio atau Android SDK.

## Cara build dari browser

1. Login ke GitHub dan buat repository baru, misalnya `sileya-printer-bridge`.
2. Upload seluruh isi folder project ini ke root repository. Folder `.github` wajib ikut ter-upload.
3. Buka tab **Actions**.
4. Pilih **Build Sileya Printer Bridge APK**.
5. Klik **Run workflow** lalu **Run workflow**.
6. Tunggu job selesai (centang hijau).
7. Buka hasil job lalu download artifact **Sileya-Printer-Bridge-APK**.
8. Extract artifact. File installernya adalah `app-debug.apk`.
9. Kirim `app-debug.apk` ke tablet dan install.

## Setelah install di tablet

- Pair kedua printer lewat Settings Android.
- Buka Sileya Printer Bridge.
- Izinkan Bluetooth/notification jika diminta.
- Pilih Printer Kasir dan Printer Dapur.
- Tekan Simpan Mapping.
- Tekan Mulai Bridge.
- Tes Printer Kasir lalu Tes Printer Dapur.
