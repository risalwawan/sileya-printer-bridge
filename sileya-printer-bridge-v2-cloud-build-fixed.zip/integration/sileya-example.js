// Setelah Sileya Printer Bridge terpasang dan kedua test printer berhasil:
const SILEYA_BRIDGE = 'http://127.0.0.1:9200';

async function bridgePrint(role, content, reference = '') {
  const response = await fetch(SILEYA_BRIDGE + '/print', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      role,              // "cashier" atau "kitchen"
      paperWidth: 58,
      cut: false,
      reference,
      content
    })
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.detail || body.error || 'Print gagal');
  return body;
}

// Contoh:
// await bridgePrint('cashier', receiptPayload.content, receipt.codes);
// await bridgePrint('kitchen', kitchenPayload.content, 'MEJA-' + receipt.table);
